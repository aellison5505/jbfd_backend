"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const server_1 = require("./server");
const server = new server_1.awsServer();
exports.handler = (event, context) => server.proxy(event, context);
