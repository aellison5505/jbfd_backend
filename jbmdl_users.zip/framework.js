"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express = require("express");
const middleware = require("aws-serverless-express/middleware");
const bodyParser = require("body-parser");
const cors = require("cors");
const compression = require("compression");
class server {
    constructor() {
        this.app = express();
        this.config();
    }
    config() {
        this.app.use(compression());
        this.app.use(cors());
        this.app.use(bodyParser.json());
        this.app.use(bodyParser.urlencoded({ extended: true }));
        this.app.use(middleware.eventContext());
        this.routes();
    }
    get getApp() {
        return this.app;
    }
    routes() {
        this.app.get('/newUser', (req, res) => {
            res.json({
                "test": 'worked'
            });
        });
    }
    listener(port) {
        this.app.listen(port);
        console.log(`listening on http://localhost:${port}`);
    }
}
exports.server = server;
